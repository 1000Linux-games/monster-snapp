# Monster Snapp
Ein Spiel, in dem du Monster in eine Kiste stoßen musst.