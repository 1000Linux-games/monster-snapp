---
name: "Quality Guidelines"
about: "Feedback or support regarding Flathub Quality Guidelines"
title: "Quality guideline problems for <app name>"
---

<!-- ⚠️⚠️  Please use this template ONLY for Quality Guidelines Support ⚠️⚠️  -->

<!-- https://docs.flathub.org/docs/for-app-authors/metainfo-guidelines/quality-guidelines -->

### Flathub store page link

<!-- https://flathub.org/apps/com.example.myapp -->

### Questions or Feedback
